﻿using M03UF4Exercicis;
namespace M03UF4Exs
{
    class PersonaInstance
    {
        static void Main()
        {
            Persona persona = new Persona();
            persona.SetNom(Console.ReadLine());
            persona.SetCognom(Console.ReadLine());
            persona.SetAge(Convert.ToInt32(Console.ReadLine()));
            Console.WriteLine("Nombre: {0} {1}, edad: {2}", persona.GetNom(), persona.GetCognom(), persona.GetAge());
        }
    }
}