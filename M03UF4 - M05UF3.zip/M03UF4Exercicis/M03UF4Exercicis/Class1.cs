﻿namespace M03UF4Exercicis
{
    public class Persona
    {
        private string nom, cognom;
        private int edat;

        public int GetAge() { return edat; }
        public void SetAge(int edat) { this.edat = edat; }
        public string GetNom() { return nom; }
        public void SetNom(string nom) { this.nom = nom; }
        public string GetCognom() { return cognom; }
        public void SetCognom(string cognom) { this.cognom = cognom; }
    }
}
