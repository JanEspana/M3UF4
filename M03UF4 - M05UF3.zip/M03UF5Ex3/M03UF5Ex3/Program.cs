﻿using System.Data;

namespace M03UF5Ex3
{
    public class Program
    {
        public static void Main()
        {
            Data data1 = new Data(1, 1, 2021);
            DateTime data = DateTime.Now;
        }
    }
}