﻿namespace M03UF5Ex3
{
    public class Data
    {
        public int Dia { get; set; }
        public int Mes { get; set; }
        public int Any { get; set; }
        public int Hora { get; set; }
        public int Minut { get; set; }
        public int Segon { get; set; }
        public Data (int dia, int mes, int any, int hora, int minut, int segon)
        {
            Dia = dia;
            Mes = mes;
            Any = any;
            Hora = hora;
            Minut = minut;
            Segon = segon;
        }
        public Data (int dia, int mes, int any): this(dia, mes, any, 0, 0, 0){}
    }
}
