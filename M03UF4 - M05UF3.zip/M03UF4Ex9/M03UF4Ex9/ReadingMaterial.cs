﻿using System.Reflection.Metadata;

namespace M03UF4Ex9
{
    public abstract class ReadingMaterial
    {
        public string Title { get; set; }
        public string Editorial { get; set; }
        public string PublicationDate { get; set; }
        public int Volume { get; set; }
        public int Pages { get; set; }
        public string Author { get; set; }
        public string Category { get; set; }
        public abstract string ReadingLanguage();

        public ReadingMaterial(string title, string editorial, string publicationDate, int volume, int pages, string author, string category)
        {
            Title = title;
            Editorial = editorial;
            PublicationDate = publicationDate;
            Volume = volume;
            Pages = pages;
            Author = author;
            Category = category;
        }
    }
}
