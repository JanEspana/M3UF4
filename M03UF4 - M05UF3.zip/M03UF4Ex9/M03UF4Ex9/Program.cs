﻿using System;
namespace M03UF4Ex9
{
    public class Program
    {
        public static void Main()
        {
            Book book = new Book("El Quijote", "Anaya", "1605", 1, 1000, "Cervantes", "Novel", "978-84-206-5294-7", "Spanish", "Hardcover");
            Console.WriteLine(book.ReadingLanguage());
            Magazine magazine = new Magazine("Muy Interesante", "G+J", "1981", 1, 100, "Various", "Science", "0214-9848", "English", "Science");
            Console.WriteLine(magazine.ReadingLanguage());
            Newspaper newspaper = new Newspaper("El País", "Prisa", "1976", 1, 50, "Various", "News", "0214-9848", "Spanish", "Paper");
            Console.WriteLine(newspaper.ReadingLanguage());
        }
    }
}