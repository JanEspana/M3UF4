﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace M03UF4Ex9
{
    public interface IPrestar
    {
        public string LendDate { get; set; }
        public bool Returned { get; set; }
        public string Lend();
        public string Return();
        public string Status();
    }
}
