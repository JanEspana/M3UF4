﻿namespace M03UF4Ex9
{
    public class Book : ReadingMaterial, IPrestar
    {
        public string ISBN { get; set; }
        public string Language { get; set; }
        public string CoverType { get; set; }
        public string LendDate { get; set; }
        public bool Returned { get; set; }
        override public string ReadingLanguage()
        {
            return $"You can read it in {Language}.";
        }
        public string Lend()
        {
            if (Returned)
            {
                LendDate = System.DateTime.Now.ToString("dd/MM/yyyy");
                Returned = false;
                return "Book lent.";
            }
            else
            {
                return "Book already lent.";
            }
        }
        public string Return()
        {
            if (!Returned)
            {
                LendDate = "";
                Returned = true;
                return "Book returned.";
            }
            else
            {
                return "Book already returned.";
            }
        }
        public string Status()
        {
            if (Returned)
            {
                return "Book available.";
            }
            else
            {
                return "Book lent.";
            }
        }
        public Book(string title, string editorial, string publicationDate, int volume, int pages, string author, string category, string isbn, string language, string coverType) : base(title, editorial, publicationDate, volume, pages, author, category)
        {
            ISBN = isbn;
            Language = language;
            CoverType = coverType;
            LendDate = "";
            Returned = true;
        }
    }
}
