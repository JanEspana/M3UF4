﻿namespace M03UF4Ex9
{
    public class Magazine : ReadingMaterial
    {
        public string ISSN { get; set; }
        public string Language { get; set; }
        public string MagazineGenre { get; set; }
        public string LendDate { get; set; }
        public bool Returned { get; set; }
        override public string ReadingLanguage()
        {
            return $"You can read it in {Language}.";
        }
        public string Lend()
        {
            if (Returned)
            {
                LendDate = System.DateTime.Now.ToString("dd/MM/yyyy");
                Returned = false;
                return "Book lent.";
            }
            else
            {
                return "Book already lent.";
            }
        }
        public string Return()
        {
            if (!Returned)
            {
                LendDate = "";
                Returned = true;
                return "Book returned.";
            }
            else
            {
                return "Book already returned.";
            }
        }
        public string Status()
        {
            if (Returned)
            {
                return "Book available.";
            }
            else
            {
                return "Book lent.";
            }
        }
        public Magazine(string title, string editorial, string publicationDate, int volume, int pages, string author, string category, string issn, string language, string magazineGenre) : base(title, editorial, publicationDate, volume, pages, author, category)
        {
            ISSN = issn;
            Language = language;
            MagazineGenre = magazineGenre;
        }
    }
}
