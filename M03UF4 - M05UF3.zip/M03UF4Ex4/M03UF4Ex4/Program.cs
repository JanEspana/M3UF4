﻿using M03UF4Ex4;

namespace Gatitos
{
    public class Program
    {
        public static void Main()
        {
            Cat cat1 = new Cat("Gualtrapo", 2, "orange", "human flesh");
            Console.WriteLine("CAT #1:\n-----------\nName: {0}\nAge: {1}\nBreed: {2}\nFavourite food: {3}",
                cat1.GetName(), cat1.GetAge(), cat1.GetBreed(), cat1.GetFavFood());
            Console.WriteLine();
            Cat cat2 = new Cat("Arnoldo", 3, "black", "dirt");
            Console.WriteLine("CAT #2:\n-----------\nName: {0}\nAge: {1}\nBreed: {2}\nFavourite food: {3}",
                cat2.GetName(), cat2.GetAge(), cat2.GetBreed(), cat2.GetFavFood());
        }
    }
}