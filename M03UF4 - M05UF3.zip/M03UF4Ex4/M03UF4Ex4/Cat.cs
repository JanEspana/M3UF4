﻿namespace M03UF4Ex4
{
    public class Cat
    {
        private string name;
        private int age;
        private string breed;
        private string favFood;

        public void SetName(string name) { this.name = name; }
        public string GetName() { return this.name; }
        public void SetAge(int age) { this.age = age; }
        public int GetAge() { return this.age; }
        public void SetBreed(string breed) { this.breed = breed; }
        public string GetBreed() { return this.breed; }
        public void SetFavFood(string favFood) { this.favFood = favFood; }
        public string GetFavFood() { return this.favFood; }

        public Cat(string name, int age, string breed, string favFood)
        {
            SetName(name);
            SetAge(age);
            SetBreed(breed);
            SetFavFood(favFood);
        }
    }
}
