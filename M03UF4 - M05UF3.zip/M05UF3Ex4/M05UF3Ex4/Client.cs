﻿namespace M05UF3Ex4
{
    public class Client : Persona
    {
        public int CodiClient { get; set; }
        public int TipusClient { get; set; }
        public override void Saludar()
        {
            System.Console.WriteLine("Hola, sóc un client");
        }
        public Client (string nom, string cognom, int codi, int tipusClient) : base(nom, cognom, codi)
        {

        }
    }
}
