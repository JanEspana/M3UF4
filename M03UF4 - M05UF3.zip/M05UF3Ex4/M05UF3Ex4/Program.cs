﻿using System;
namespace M05UF3Ex4
{
    public class Program
    {
        public static void Main()
        {

        }
    }
}