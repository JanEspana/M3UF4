﻿namespace M05UF3Ex4
{
    public abstract class Persona
    {
        public string Nom { get; set; }
        public string Cognom { get; set; }
        public int Codi { get; set; }
        public abstract void Saludar();

        public Persona(string nom, string cognom, int codi)
        {
            Nom = nom;
            Cognom = cognom;
            Codi = codi;
        }
    }
}
