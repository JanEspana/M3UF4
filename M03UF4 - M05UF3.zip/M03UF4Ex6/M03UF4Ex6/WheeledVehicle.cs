﻿namespace M03UF4Ex6
{
    public class WheeledVehicle : Vehicle
    {
        public override bool IsOld() => Age > 5;
        public override bool IsFast() => MaxSpeed > 100;
        public WheeledVehicle(string brand, int maxSpeed, int age) : base(brand, maxSpeed, age)
        {
            MaxSpeed = maxSpeed;
            Age = age;
        }
        public WheeledVehicle(string brand, int maxSpeed) : this(brand, maxSpeed, 0) { }
        public WheeledVehicle(string brand) : this(brand, 0, 0) { }
        public WheeledVehicle() : this("No brand", 0, 0) { }
        public WheeledVehicle(int maxSpeed, int age) : this("No brand", maxSpeed, age) { }
        public WheeledVehicle(int maxSpeed) : this("No brand", maxSpeed, 0) { }
    }
}
