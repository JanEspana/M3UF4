﻿using System;
namespace M03UF4Ex6
{
    public class Program
    {
        public static void Main()
        {
            Ship ship = new Ship(100, 3, true);
            Console.WriteLine(ship.IsWindPowered());

            Bike bike = new Bike(2, 2);
            Console.WriteLine(bike.IsOld());
        }
    }
}