﻿namespace M03UF4Ex6
{
    public class Ship : Vehicle
    {
        public override bool IsOld() => Age > 10;
        public override bool IsFast() => MaxSpeed > 50;
        public bool IsWindPowered() => windPowered;
        public bool windPowered { get; set; }
        public Ship (string brand, int maxSpeed, int age, bool windPowered){ }
        public Ship (string brand, int maxSpeed, int age) : base(brand, maxSpeed, age) { }
        public Ship (string brand, int maxSpeed) : base(brand, maxSpeed, 0) { }
        public Ship (string brand) : base(brand, 0, 0) { }
        public Ship () : base("No brand", 0, 0) { }
        public Ship (int maxSpeed, int age) : base(maxSpeed, age) { }
        public Ship (int maxSpeed, bool windPowered) { }
        public Ship (int maxSpeed, int age, bool windPowered) : base(maxSpeed, age) { }
        public Ship (int maxSpeed) : base(maxSpeed, 0) { }
    }
}
