﻿namespace M03UF4Ex6
{
    internal class Bike : WheeledVehicle
    {
        public override bool IsOld() => Age > 3;
        public override bool IsFast() => MaxSpeed > 30;
        public Bike(string brand, int maxSpeed, int age) : base(brand, maxSpeed, age)
        {
            MaxSpeed = maxSpeed;
            Age = age;
        }
        public Bike(string brand, int maxSpeed) : base(brand, maxSpeed, 0) { }
        public Bike(string brand) : base(brand, 0, 0) { }
        public Bike() : base("No brand", 0, 0) { }
        public Bike(int maxSpeed, int age) : base(maxSpeed, age)
        {
            MaxSpeed = maxSpeed;
            Age = age;
        }
    }
}
