﻿namespace M03UF4Ex6
{
    public abstract class Vehicle
    {
        public string Brand { get; set; }
        public int MaxSpeed { get; set; }
        public int Age { get; set; }
        public abstract bool IsOld();
        public abstract bool IsFast();
        public Vehicle(string brand, int maxSpeed, int age)
        {
            Brand = brand;
            MaxSpeed = maxSpeed;
            Age = age;
        }
        public Vehicle(string brand, int maxSpeed) : this(brand, maxSpeed, 0) { }
        public Vehicle(string brand) : this(brand, 0, 0) { }
        public Vehicle() : this("No brand", 0, 0) { }
        public Vehicle(int maxSpeed, int age) : this("No brand", maxSpeed, age) { }
        public Vehicle(int maxSpeed) : this("No brand", maxSpeed, 0) { }
    }
}
