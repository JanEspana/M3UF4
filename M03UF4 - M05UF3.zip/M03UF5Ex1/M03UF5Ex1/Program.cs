﻿namespace M03UF5Ex1
{
    public class Program
    {
        static void Main()
        {
            Book book1 = new Book(1, "El Quijote", 1560);
            Book book2 = new Book(2, "El Señor de los Anillos", 1392);
            Book book3 = new Book(3, "El Hobbit", 310);
            Book book4 = new Book(4, "El código Da Vinci", 656);
            Book book5 = new Book(5, "El Principito", 120);

            List<Book> books = [book5, book4, book1, book2, book3];
            books.Sort();
            foreach (Book book in books)
            {
                Console.WriteLine(book);
            }
        }
    }


    public class Book : IComparable<Book>
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public int NumPages { get; set; }
        public Book(int id, string title, int numPages)
        {
            Id = id;
            Title = title;
            NumPages = numPages;
        }
        public Book() : this(0, "", 0) {}
        public override string ToString()
        {
            return $"---- BOOK #{Id} ----\n"+
                   $"Title: {Title}\n"+
                   $"Number of pages: {NumPages}\n";
        }
        
        public int CompareTo(Book? other)
        {
            if (other == null) return 1;
            return NumPages.CompareTo(other.NumPages);
        }
    }
}
