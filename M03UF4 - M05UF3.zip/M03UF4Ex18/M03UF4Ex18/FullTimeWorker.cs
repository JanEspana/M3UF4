﻿namespace M03UF4Ex18
{
    public class FullTimeWorker : Worker
    {
        public const int HoursWorked = 8;
        public FullTimeWorker(string name, double salaryRate) : base(name, salaryRate) { }
        public override double ComputePay()
        {
            return SalaryRate * HoursWorked;
        }
        public override string ToString()
        {
            return $"L'empleat {GetName()} guanya {ComputePay()} euros diaris.";
        }
    }
}
