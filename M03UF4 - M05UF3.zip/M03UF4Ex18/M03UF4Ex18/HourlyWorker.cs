﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace M03UF4Ex18
{
    public class HourlyWorker : Worker
    {
        public int HoursWorked { get; set; }
        public HourlyWorker(string name, double salaryRate, int hoursWorked) : base(name, salaryRate)
        {
            this.HoursWorked = hoursWorked;
        }
        public override double ComputePay()
        {
            return SalaryRate * HoursWorked;
        }
        public override string ToString()
        {
            return $"L'empleat {GetName()} guanya {ComputePay()} euros diaris.";
        }
    }
}
