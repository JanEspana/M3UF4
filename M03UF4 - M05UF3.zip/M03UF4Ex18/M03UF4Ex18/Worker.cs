﻿namespace M03UF4Ex18
{
    public abstract class Worker
    {
        public string Name { get; set; }
        public double SalaryRate { get; set; }

        public string GetName()
        {
            return Name;
        }
        public string GetSalaryRate()
        {
            return SalaryRate.ToString();
        }
        public void SetName(string name)
        {
            Name = name;
        }
        public void SetSalaryRate(double salaryRate)
        {
            SalaryRate = salaryRate;
        }
        public abstract double ComputePay();
        public Worker(string name, double salaryRate)
        {
            Name = name;
            SalaryRate = salaryRate;
        }
    }
}
