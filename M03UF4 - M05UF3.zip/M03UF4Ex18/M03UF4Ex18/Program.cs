﻿using System;
namespace M03UF4Ex18
{
    public class Program
    {
        public static void Main()
        {
            Worker pepe = new HourlyWorker("Pepe", 10, 5);
            Worker paco = new FullTimeWorker("Paco", 10);
            Console.WriteLine(pepe);
            Console.WriteLine(paco);
        }
    }
}