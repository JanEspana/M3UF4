﻿namespace M03UF4Ex16
{
    public class PaymentCard
    {
        private double balance;
        public double GetBalance()
        {
            return balance;
        }
        public void SetBalance(double balance)
        {
            this.balance = balance;
        }
        public PaymentCard(double openingBalance)
        {
            this.balance = openingBalance;
        }

        public override string ToString()
        {
            return "The card has a balance of " + GetBalance() + " euros";
        }
    }
}