﻿using System;
namespace M03UF4Ex16
{
    class Program
    {
        public static void Main()
        {
            PaymentCard card = new PaymentCard(50);
            Console.WriteLine(card);
            card.SetBalance(150);
            Console.WriteLine(card);
        }
    }
}