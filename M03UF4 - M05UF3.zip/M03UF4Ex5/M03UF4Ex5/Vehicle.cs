﻿namespace M03UF4Ex6
{
    public class Vehicle
    {
        public string Brand { get; set; }
        public int Year { get; set; }
        public string Color { get; set; }
        public Vehicle (string brand, int year, string color)
        {
            Brand = brand;
            Year = year;
            Color = color;
        }
    }
}
