﻿using System;
namespace M03UF4Ex6
{
    public class Program
    {
        public static void Main()
        {

        }
    }
}