﻿namespace M03UF4Ex6
{
    public class Ship : Vehicle
    {
        public int MaxSpeed { get; set; }
        public Ship(string brand, int year, string color, int maxSpeed) : base(brand, year, color)
        {
            MaxSpeed = maxSpeed;
        }
    }
}
