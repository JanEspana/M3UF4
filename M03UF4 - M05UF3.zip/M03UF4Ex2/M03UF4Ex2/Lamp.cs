﻿using System;
namespace OOP_Ex2
{
    public class Lamp
    {
        private bool isOn;
        private string color;
        private int power;

        public void SetIsOn(bool isOn) { this.isOn = isOn; }
        public bool GetIsOn() { return isOn; }
        public void SetColor(string color) { this.color = color; }
        public string GetColor() { return color; }
        public void SetPower(int power) { this.power = power; }
        public int GetPower() { return power; }

        public Lamp(bool isOn, string color, int power)
        {
            SetIsOn(isOn);
            SetColor(color);
            SetPower(power);
        }
    }
}
