﻿using System;
namespace OOP_Ex2
{
    public class Card
    {
        private string color;
        private int number;

        public void SetColor(string color) { this.color = color; }
        public string GetColor() { return color; }

        public void SetNumber(int number) { this.number = number; }
        public int GetNumber() { return number; }
        public Card(string color, int number)
        {
            SetColor(color);
            SetNumber(number);
        }
    }
}
