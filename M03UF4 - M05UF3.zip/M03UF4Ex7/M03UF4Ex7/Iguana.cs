﻿namespace M03UF4Ex7
{
    public class Iguana : Animal, Walks
    {
        public string SkinColor { get; set; }
        public override string MakeSound() => Sound;
        public string Walk() => "Iguana walks";
        public Iguana(string name, int age, string sound, string skinColor) : base(name, age, sound)
        {
            SkinColor = skinColor;
        }
    }
}
