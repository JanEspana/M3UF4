﻿namespace M03UF4Ex7
{
    public interface Walks
    {
        public string Walk();
    }
}
