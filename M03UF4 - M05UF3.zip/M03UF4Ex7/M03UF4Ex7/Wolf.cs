﻿using System.Drawing;

namespace M03UF4Ex7
{
    public class Wolf : Animal, Walks
    {
        public string FurColor { get; set; }
        public override string MakeSound() => Sound;
        public string Walk() => "Wolf walks fast";
        public Wolf(string name, int age, string sound, string furColor) : base(name, age, sound)
        {
            FurColor = furColor;
        }
    }
}
