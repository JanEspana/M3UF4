﻿using System;
namespace M03UF4Ex7
{
    class Program
    {
        static void Main()
        {
            Wolf wolf = new Wolf("Rex", 5, "BORRA LA CUENTA", "gray");
            Console.WriteLine($"The {wolf.GetType().Name} {wolf.Name} is {wolf.Age} " +
                $"years old and has {wolf.FurColor} fur. It says {wolf.MakeSound()}. {wolf.Walk()}");
        
            Iguana iguana = new Iguana("Iggy", 2, "BORRA LA CUENTA", "green");
            Console.WriteLine($"The {iguana.GetType().Name} {iguana.Name} is {iguana.Age} " +
                $"years old and has {iguana.SkinColor} skin. It says {iguana.MakeSound()}. {iguana.Walk()}");

            Turtle turtle = new Turtle("Bob", 3, "BORRA LA CUENTA", "brown");
            Console.WriteLine($"The {turtle.GetType().Name} {turtle.Name} is {turtle.Age} " +
                $"years old and has a {turtle.ShellColor} shell. It says {turtle.MakeSound()}. {turtle.Walk()}");
        }
    }
}