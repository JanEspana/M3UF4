﻿namespace M03UF4Ex7
{
    public class Turtle : Animal, Walks
    {
        public string ShellColor { get; set; }
        public override string MakeSound() => Sound;
        public string Walk() => "Turtle walks slowly";
        public Turtle(string name, int age, string sound, string shellColor) : base(name, age, sound)
        {
            ShellColor = shellColor;
        }
    }
}
