﻿namespace M03UF5Ex2
{
    public class Visita : IComparable
    {
        public Pacient Pacient { get; set; }
        public Propietari Propietari { get; set; }
        public DateTime Data { get; set; }
        public string Motiu { get; set; }
        public Visita(Pacient pacient, Propietari propietari, DateTime data, string motiu)
        {
            Pacient = pacient;
            Propietari = propietari;
            Data = data;
            Motiu = motiu;
        }
        public override string ToString()
        {
            return $"Visita a {Pacient.Nom} ({Pacient.Edat}) - {Data} - {Motiu}";
        }
        public int CompareTo(object obj)
        {
            Visita v = (Visita)obj;
            return Data.CompareTo(v.Data);
        }
    }
}
