﻿namespace M03UF5Ex2
{
    public class Pacient
    {
        public string Nom { get; set; }
        public string Raça { get; set; }
        public int Edat { get; set; }
        public bool Vacunat { get; set; }
        public Pacient(string nom, string cognom, int edat, bool vacunat)
        {
            Nom = nom;
            Raça = cognom;
            Edat = edat;
            Vacunat = vacunat;
        }
        public override string ToString()
        {
            return $"{Nom} ({Edat}), raça {Raça} - Vacunat? {Vacunat}";
        }
    }
}
