﻿using System;
namespace M03UF5Ex2
{
    public class Program
    {
        public static void Main()
        {
            Propietari propietari = new Propietari("Joan", "Garcia", 35, "12345678A");
            Pacient pacient = new Pacient("Bobby", "Golden Retriever", 5, true);
            Visita visita = new Visita(pacient, propietari, DateTime.Now, "Vacunació");

            Propietari propietari2 = new Propietari("Maria", "Lopez", 45, "87654321B");
            Pacient pacient2 = new Pacient("Lluna", "Gat", 2, false);
            DateTime dateTime2 = new DateTime(2021, 1, 1, 11, 31, 1);
            Visita visita2 = new Visita(pacient2, propietari2, dateTime2, "Revisió");

            Propietari propietari3 = new Propietari("Pere", "Martínez", 25, "11111111C");
            Pacient pacient3 = new Pacient("Rex", "Pastor Alemany", 3, true);
            DateTime dateTime3 = new DateTime(2021, 3, 1, 10, 30, 13);
            Visita visita3 = new Visita(pacient3, propietari3, dateTime3, "Vacunació");

            Propietari propietari4 = new Propietari("Anna", "Garcia", 35, "22222222D");
            Pacient pacient4 = new Pacient("Mimi", "Gat", 1, false);
            DateTime dateTime4 = new DateTime(2021, 2, 1, 12, 2, 4);
            Visita visita4 = new Visita(pacient4, propietari4, dateTime4, "Revisió");

            Propietari propietari5 = new Propietari("Pau", "Martínez", 25, "33333333E");
            Pacient pacient5 = new Pacient("Lluna", "Pastor Alemany", 3, true);
            DateTime dateTime5 = new DateTime(2021, 4, 1, 10, 31, 11);
            Visita visita5 = new Visita(pacient5, propietari5, dateTime5, "Vacunació");

            List<Visita> visites = new List<Visita> { visita, visita2, visita3, visita4, visita5 };

            visites.Sort();

            foreach (Visita v in visites)
            {
                Console.WriteLine(v);
            }
        }
    }
}
