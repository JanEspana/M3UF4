﻿namespace M03UF5Ex2
{
    public class Propietari
    {
        public string Nom { get; set; }
        public string Cognom { get; set; }
        public int Edat { get; set; }
        public string DNI { get; set; }
        public Propietari(string nom, string cognom, int edat, string dni)
        {
            Nom = nom;
            Cognom = cognom;
            Edat = edat;
            DNI = dni;
        }
        public override string ToString()
        {
            return $"{Nom} {Cognom} ({Edat}) - {DNI}";
        }
    }
}
