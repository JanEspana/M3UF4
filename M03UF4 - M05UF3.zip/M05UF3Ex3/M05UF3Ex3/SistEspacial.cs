﻿namespace M05UF3Ex3
{
    public class SistEspacial
    {
        private int Rocket { get; set; }
        private int SistNavegacio { get; set; }
        private bool IA { get; set; }
        private bool ControlManual { get; set; }
        private bool Orbita { get; set; }

        private int calcAngle()
        {
            if (Orbita)
            {
                return 90;
            }
            else
            {
                return 0;
            }
        }
        public SistEspacial(int rocket, int sistNavegacio, bool iA, bool controlManual)
        {
            Rocket = rocket;
            SistNavegacio = sistNavegacio;
            IA = iA;
            ControlManual = controlManual;
        }
    }
}
