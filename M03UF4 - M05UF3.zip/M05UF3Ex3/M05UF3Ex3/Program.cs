﻿using System;
namespace M05UF3Ex3
{
    class Program
    {
        static void Main()
        {
            
        }
    }
}